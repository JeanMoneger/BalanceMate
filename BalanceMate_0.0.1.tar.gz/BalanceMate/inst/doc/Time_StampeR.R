## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)
library(knitr)
library(kableExtra)
library(ggplot2)

## ----echo = F, warning = FALSE, message=F-------------------------------------
# Load the required packages

# if (requireNamespace("knitr", quietly = TRUE)) {
#   library(knitr)
# }
# if (requireNamespace("kableExtra", quietly = TRUE)) {
#   library(kableExtra)
# }
# if (requireNamespace("ggplot2", quietly = TRUE)) {
#   library(ggplot2)
# }
# Define the data
time_periods <- data.frame(
  Periods = c("Training (20s)", 
              "Fixation Cross (5s)", 
              "Unpleasant trial (15s)", 
              "Fixation Cross (5s)", 
              "Pleasant trial (15s)", 
              "Fixation Cross (5s)", 
              "Unpleasant trial (15s)", 
              "Fixation Cross (5s)", 
              "Pleasant trial (15s)"), 
  Label = c("Training", "Fix", "Unpl_Trial", "Fix", "Pleas_Trial", "Fix", "Unpl_Trial",
            "Fix", "Pleas_Trial"),
  `End Time (s)` = c(20, 
                     25, 
                     40, 
                     45, 
                     60, 
                     65, 
                     80, 
                     85, 
                     100)
)

# Create a neat HTML table
kableExtra::kable(time_periods, format = "html", col.names = c("Periods of interest", "Label", "End Time (s)"), table.attr = "style='width:50%;'") %>%
  kable_styling(
    full_width = FALSE, 
    bootstrap_options = c("striped", "hover", "condensed", "responsive"),
    position = "center"
  ) 


## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)

# Identify the time cuts in your protocol: 
cuts<-c(20, 
        25, 
        40, 
        45, 
        60, 
        65, 
        80, 
        85)

# Label the periods:
Labels = c("Training", 
              "Fix", 
              "Unpleasant_t", 
              "Fix", 
              "Pleasant_t", 
              "Fix", 
              "Unpleasant_t", 
              "Fix", 
              "Pleasant_t")

Annotated_Data <- Time_StampeR(df = Data, id_col = "file_name", sample_rate = 100, protocol_duration = 100, cuts = cuts, period_names = Labels)

head(Annotated_Data)

tail(Annotated_Data)


## -----------------------------------------------------------------------------
Crit_Data <- subset(Annotated_Data, Annotated_Data$Period_Name=="Unpleasant_t" | Annotated_Data$Period_Name == "Pleasant_t")

head(Crit_Data)

tail(Crit_Data)

