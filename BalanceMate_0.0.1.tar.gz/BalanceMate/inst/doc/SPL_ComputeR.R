## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)

## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)


BalanceMate::SPL_ComputeR(data = Data, CoPX_col = "CoP_X", CoPY_col = "CoP_Y", ID = "file_name", time_col = "Time", epoch_length = 50)

