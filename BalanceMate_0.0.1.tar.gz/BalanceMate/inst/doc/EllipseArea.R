## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)

## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)


SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataA.txt")


## -----------------------------------------------------------------------------

RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 5. Merge from the tempdir
Data <- Merge_PosData(
  tmpdir,              # first, unnamed argument is the folder of .txt files
  SampleRate     = 100,
  SessionDuration= 100
)


## -----------------------------------------------------------------------------
BalanceMate::compute_ellipse_area(data = Data, 
                                  CoPX_col = "CoP_X", 
                                  CoPY_col = "CoP_Y", 
                                  ID = "file_name"
                                  )

## -----------------------------------------------------------------------------
SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataA.txt", Title = "Participant A")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataB.txt", Title = "Participant B")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataC.txt", Title = "Participant C")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataD.txt", Title = "Participant D")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataE.txt", Title = "Participant E")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataF.txt", Title = "Participant F")


## -----------------------------------------------------------------------------
BalanceMate::compute_ellipse_area(data = Data, 
                                  CoPX_col = "CoP_X", 
                                  CoPY_col = "CoP_Y", 
                                  ID = "file_name", 
                                  time_col = "Time", 
                                  epoch_length = 25)

## -----------------------------------------------------------------------------
BalanceMate::compute_ellipse_area(data = Data, 
                                  CoPX_col = "CoP_X", 
                                  CoPY_col = "CoP_Y", 
                                  ID = "file_name", 
                                  confint = .8)

## -----------------------------------------------------------------------------
SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataA.txt",conf_level = .8, Title = "Participant A")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataB.txt", conf_level = .8,Title = "Participant B")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataC.txt",conf_level = .8, Title = "Participant C")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataD.txt",conf_level = .8, Title = "Participant D")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataE.txt",conf_level = .8, Title = "Participant E")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataF.txt",conf_level = .8, Title = "Participant F")


