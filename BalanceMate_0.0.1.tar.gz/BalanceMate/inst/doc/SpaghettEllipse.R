## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)

## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)



SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataA.txt", Title = "Participant A")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataB.txt", Title = "Participant B")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataC.txt", Title = "Participant C")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataD.txt", Title = "Participant D")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataE.txt", Title = "Participant E")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataF.txt", Title = "Participant F")

## -----------------------------------------------------------------------------
#path_to_data <- system.file("extdata", package = "BalanceMate")
#Data <- Merge_PosData(path_to_data, SampleRate = 100, SessionDuration = 100)

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataA.txt", time_col = "Time", time_start = 10, time_end = 90, Title = "Participant A")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataB.txt",  time_col = "Time", time_start = 10, time_end = 90,Title = "Participant B")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataC.txt",  time_col = "Time", time_start = 10, time_end = 90,Title = "Participant C")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataD.txt",  time_col = "Time", time_start = 10, time_end = 90,Title = "Participant D")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataE.txt",  time_col = "Time", time_start = 10, time_end = 90,Title = "Participant E")

SpaghettEllipse(Data, participant_id_col = "file_name", participant_id = "Postural_DataF.txt",  time_col = "Time", time_start = 10, time_end = 90,Title = "Participant F")

