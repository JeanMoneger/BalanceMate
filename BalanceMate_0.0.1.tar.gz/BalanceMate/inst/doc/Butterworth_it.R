## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)
  library(knitr)
  library(kableExtra)
  library(ggplot2)


## ----echo = F, warning = FALSE, message=F-------------------------------------
# Load the required packages

# if (requireNamespace("knitr", quietly = TRUE)) {
#   library(knitr)
# }
# if (requireNamespace("kableExtra", quietly = TRUE)) {
#   library(kableExtra)
# }
# if (requireNamespace("ggplot2", quietly = TRUE)) {
#   library(ggplot2)
# }


Filter_types_Data <- structure(list(`Filter type` = c(NA, "2nd Order Low-Pass Butterworth Filter (5Hz)", 
"Low Pass filtered (8Hz)", "2nd Order Butterworth (5Hz)", "low pass filtered (5Hz)", 
NA, "5-point moving average", "2nd Order Butterworth Filter (10Hz)", 
NA, NA, NA, NA, NA, "Unknown", "2nd order Butterworth (5Hz cutoff)", 
NA, "second-order low-pass Butterworth filter with a cutoff frequency of 10Ã\u008a Hz", 
"2nd Order Butterworth (10Hz)", "2nd Order Low-Pass Butterworth Filter (10Hz)", 
"15Hz Lowpass filter", "2nd Order Butterworth (5Hz)", "Custom Low-Pass filter", 
"None", NA, NA, "Unknown", NA, NA, "low pass filtered (10Hz)", 
"3rd order butterwoth (0.01 - 10Hz)", NA, "low-pass Butterworth filter (cut-off frequency: 5 Hz", 
"None", NA, NA, "second-order low-pass Butterworth filter with a cutoff frequency of 20Ã\u008a Hz", 
"None", "low pass filtered (5Hz)", NA, NA, NA, NA, "2nd order butterworth low pass filter 5Hz", 
NA), Filter_cutOff = c("No filter used", "5Hz", "8Hz", "5Hz", 
"5Hz", "No filter used", "Other", "10Hz", "No filter used", "No filter used", 
"No filter used", "No filter used", "No filter used", "No filter used", 
"5Hz", "No filter used", "10Hz", "10Hz", "10Hz", "15Hz", "5Hz", 
"Not enough information", "No filter used", "No filter used", 
"No filter used", "No filter used", "No filter used", "No filter used", 
"10Hz", "Not enough information", "No filter used", "5Hz", "No filter used", 
"No filter used", "No filter used", "20Hz", "No filter used", 
"5Hz", "No filter used", "No filter used", "No filter used", 
"No filter used", "5Hz", "No filter used"), Filter_Order = c("N/A", 
"2nd Order", "Unknown", "2nd Order", "Unknown", "N/A", "N/A", 
"2nd Order", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "2nd Order", 
"N/A", "2nd Order", "2nd Order", "2nd Order", "Unknown", "2nd Order", 
"Unknown", "N/A", "N/A", "N/A", "N/A", "N/A", "N/A", "Unknown", 
"3rd Order", "N/A", "Unknown", "N/A", "N/A", "N/A", "2nd Order", 
"N/A", "Unknown", "N/A", "N/A", "N/A", "N/A", "2nd Order", "N/A"
)), class = "data.frame", row.names = c(NA, -44L))

table1<- table(Filter_types_Data$Filter_cutOff)

# Create a neat HTML table
kableExtra::kable(table1, format = "html", col.names = c("Cut-off Frequency used", "Number of papers"), table.attr = "style='width:50%;'", caption = "Cut-Off Frequency usage in the literature")

table2<- table(Filter_types_Data$Filter_Order)

# Create a neat HTML table
kableExtra::kable(table2, format = "html", col.names = c("Order of the filter used", "Number of papers"), table.attr = "style='width:50%;'" , 
  caption = "Filter's order usage in the literature")


## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)

filtered_data <- Butterworth_it(
  Data = Data,
  cutoff_freq = 5,
  filter_order = 2,
  sampling_rate = 100,
  type = "low",
  Colname = c("CoP_X", "CoP_Y")
)


## ----fig.show='hold'----------------------------------------------------------
# File names
file_names <- c("Postural_DataB.txt", "Postural_DataA.txt", "Postural_DataD.txt")

# Loop through file names to generate plots side by side
for (file in file_names) {
  # Original signal plot
  plot(
    x = subset(filtered_data, filtered_data$file_name == file & filtered_data$Time > 30 & filtered_data$Time < 32)$Time,
    y = subset(filtered_data, filtered_data$file_name == file & filtered_data$Time > 30 & filtered_data$Time < 32)$CoP_Y,
    type = "l",
    main = paste("Original Signal:", file),
    xlab = "Time",
    ylab = "CoP-Y"
  )
  
  # Filtered signal plot
  plot(
    x = subset(filtered_data, filtered_data$file_name == file & filtered_data$Time > 30 & filtered_data$Time < 32)$Time,
    y = subset(filtered_data, filtered_data$file_name == file & filtered_data$Time > 30 & filtered_data$Time < 32)$CoP_Y_filtered,
    type = "l",
    main = paste("Filtered Signal:", file),
    xlab = "Time",
    ylab = "CoP-Y"
  )
}


