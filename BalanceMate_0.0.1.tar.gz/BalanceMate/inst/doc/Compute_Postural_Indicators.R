## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(BalanceMate)
library(ggplot2)


## ----echo = F, message= F, warning= F-----------------------------------------

# if (requireNamespace("ggplot2", quietly = TRUE)) {
#   library(ggplot2)
# }


outcome_df<-structure(list(Outcome = structure(1:8, levels = c("Amplitude COP", 
"Area Body Sw", "COP Y", "ErrorCoP", "MeanSpeed", "Other", "SD COP", 
"Sway Path Length"), class = "factor"), Frequency = c(1L, 3L, 
20L, 1L, 1L, 1L, 10L, 7L)), class = "data.frame", row.names = c(NA, 
-8L))

ggplot2::ggplot(outcome_df, aes(x = Outcome, y = Frequency, fill = Outcome)) +
  geom_bar(stat = "identity", show.legend = FALSE) +
  theme_minimal(base_size = 12) +
  labs(
    title = "Outcomes",
    x = "Outcome Categories",
    y = "Frequency",
    caption = "Source: Monéger et al., 2024"
  ) +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold"),
    axis.title.x = element_text(margin = margin(t = 10)),
    axis.title.y = element_text(margin = margin(r = 10)),
    axis.text.x = element_text(angle = 45, hjust = 1)
  ) +
  scale_fill_brewer(palette = "Set3")  # You can change the palette as needed


## -----------------------------------------------------------------------------
# 1. Locate the installed extdata/ folder (contains only .RData now)
path_extdata <- system.file("extdata", package = "BalanceMate")

# 2. Find all .RData (case‐insensitive)
RData_files <- list.files(
  path_extdata,
  pattern    = "\\.[Rr][Dd]ata$",
  full.names = TRUE
)

# 3. Convert each .RData to a .txt in a temp directory
tmpdir <- tempdir()
for (f in RData_files) {
  load(f)  # e.g. loads object “Postural_DataA” into your session
  nm <- tools::file_path_sans_ext(basename(f))
  write.table(
    get(nm),
    file      = file.path(tmpdir, paste0(nm, ".txt")),
    sep       = ",",
    row.names = FALSE,
    col.names = FALSE,
    quote     = FALSE
  )
}


# 4. Merge from the tempdir
Data <- Merge_PosData(
  directory_path = tmpdir,              
  SampleRate     = 100,
  SessionDuration= 100
)


# Identify the time cuts in your protocol: 
cuts<-c(20, 
                     22, 
                     30, 
                     32, 
                     40, 
                     42, 
                     50, 
                     52, 
                     60, 
                     62, 
                     70, 
                     72, 
                     80, 
                     82,
                     90, 
                     92)

# Label the periods:
Label = c("Training", 
          "Fix", 
          "Trial_1", 
          "Fix", 
          "Trial_2", 
          "Fix", 
          "Trial_3",
          "Fix", 
          "Trial_4", 
          "Fix", 
          "Trial_5", 
          "Fix", 
          "Trial_6", 
          "Fix", 
          "Trial_7", 
          "Fix", 
          "Trial_8") 


Annotated_Data <- Time_StampeR(df = Data, id_col = "file_name", sample_rate = 100, protocol_duration = 100, cuts = cuts, period_names = Label)

Data <- subset(Annotated_Data, Annotated_Data$Period_Name != "Blank" & Annotated_Data$Period_Name != "Fix")


## -----------------------------------------------------------------------------
CompleteData <- compute_postural_indicators(Data, CoPX_col = "CoP_X", CoPY_col = "CoP_Y", ID = "file_name", indicators = c("CoP_X", "CoP_Y", "SwayPathLength", "EllipseArea", "SD_CoP_X", "SD_CoP_Y"))

head(CompleteData)

## -----------------------------------------------------------------------------
CompleteData <- compute_postural_indicators(Data, CoPX_col = "CoP_X", CoPY_col = "CoP_Y", ID = "file_name", time_col = "Time", epoch_length = 1, indicators = c("CoP_X", "CoP_Y", "SwayPathLength", "EllipseArea", "SD_CoP_X", "SD_CoP_Y"))

head(CompleteData)

