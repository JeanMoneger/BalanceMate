
# Test if every postural index are equivalent to the ones computed by the generic wrapper command

# Compare dplyr performances with the base versions in the package
